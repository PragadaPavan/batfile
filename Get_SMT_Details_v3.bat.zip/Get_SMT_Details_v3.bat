@echo off
cls
setlocal enabledelayedexpansion enableextensions

echo ^+------------------------------------------------------------^+
echo ^| IBM CMF SMT: Basic Workstation / Server Data Capture       ^|
echo ^|            : June 2018, v1.4                               ^|
echo ^+------------------------------------------------------------^+
echo.

echo ^+------------------------------------------------------------^+
echo ^| OS: Operating System Details                               ^|
echo ^+------------------------------------------------------------^+
set SMT_OSComputername=
set SMT_OSName=
set SMT_OSType=
set SMT_TimeZone=
set SMT_NumberOfCores=
set SMT_TotalPhysicalMemory=
set SMT_DisableStrictNameChecking=
set SMT_DisableLoopbackChecking=
set SMT_OptionalNames=
set SMT_BackConnectionHostnames=

reg query "hklm\system\currentcontrolset\control\computername\computername" /v computername > nul 2> nul
if "%errorlevel%"=="0" (
    for /f "tokens=3*" %%i in ('reg query "hklm\system\currentcontrolset\control\computername\computername" /v computername') do set SMT_OSComputername=%%i
)
reg query "hklm\software\microsoft\windows nt\currentversion" /v productname > nul 2> nul
if "%errorlevel%"=="0" (
    for /f "tokens=3*" %%i in ('reg query "hklm\software\microsoft\windows nt\currentversion" /v productname') do set SMT_OSName=%%i %%j
)
reg query "hklm\hardware\description\system\centralprocessor\0" /v identifier > nul 2> nul
if "%errorlevel%"=="0" (
    for /f "tokens=3,*" %%i in ('reg query "hklm\hardware\description\system\centralprocessor\0" /v identifier') do set SMT_OSType=%%i
)
reg query hklm\system\currentcontrolset\control\timezoneinformation /v timezonekeyname > nul 2> nul
if "%errorlevel%"=="0" (
    for /f "tokens=1,2,*" %%i in ('reg query "hklm\system\currentcontrolset\control\timezoneinformation" /v timezonekeyname') do set SMT_TimeZone=%%k
)

echo COMPUTERNAME          : %SMT_OSComputername%
echo OPERATING SYSTEM      : %SMT_OSName%
echo OPERATING SYSTEM TYPE : %SMT_OSType%
echo WINDOWS DIRECTORY     : %windir%
echo.
echo TIMEZONE              : %SMT_TimeZone%
echo DATE                  : %date%
echo TIME:                 : %time%
echo.

echo ^+------------------------------------------------------------^+
echo ^| HARDWARE: CPU / RAM                                        ^|
echo ^+------------------------------------------------------------^+
for /f "tokens=*" %%f in ('wmic cpu get NumberOfCores /value ^| find "="') do set SMT_%%f
for /f "tokens=*" %%f in ('wmic computersystem get TotalPhysicalMemory  /value ^| find "="') do set SMT_%%f 

echo NUMBER OF PROCESSORS  : %number_of_processors%
echo PHYSICAL MEMORY       : %SMT_TotalPhysicalMemory%
echo.

echo ^+------------------------------------------------------------^+
echo ^| NAME RESOLUTION: DNS Name Resolution                       ^|
echo ^+------------------------------------------------------------^+
nslookup %COMPUTERNAME% | find /v "Default Server:"

echo ^+------------------------------------------------------------^+
echo ^| NETWORK: IP Address Information                            ^|
echo ^+------------------------------------------------------------^+
wmic nicconfig get index,ipenabled,ipaddress,description | find /v ""
ipconfig /all
echo.

echo ^+------------------------------------------------------------^+
echo ^| NAME CHECKING: Strict Name Checking settings               ^|
echo ^+------------------------------------------------------------^+
reg query hklm\system\currentcontrolset\services\lanmanserver\parameters /v disablestrictnamechecking > nul 2> nul
if "%errorlevel%"=="0" (
    for /f "tokens=1,2,*" %%i in ('reg query "hklm\system\currentcontrolset\services\lanmanserver\parameters" /v disablestrictnamechecking') do set SMT_DisableStrictNameChecking=%%k
)
reg query hklm\system\currentcontrolset\control\lsa /v disableloopbackcheck > nul 2> nul
if "%errorlevel%"=="0" (
    for /f "tokens=1,2,*" %%i in ('reg query "hklm\system\currentcontrolset\control\lsa" /v DisableLoopbackCheck') do set SMT_DisableLoopbackChecking=%%i
)
reg query hklm\system\currentcontrolset\services\lanmanserver\parameters /v optionalnames > nul 2> nul
if "%errorlevel%"=="0" (
    for /f "tokens=1,2,*" %%i in ('reg query "hklm\system\currentcontrolset\services\lanmanserver\parameters" /v optionalnames') do set SMT_OptionalNames=%%k
)
reg query hklm\system\currentcontrolset\control\lsa\msv1_0 /v backconnectionhostnames > nul 2> nul
if "%errorlevel%"=="0" (
    for /f "tokens=1,2,*" %%i in ('reg query "hklm\system\currentcontrolset\control\lsa\msv1_0" /v backconnectionhostnames') do set SMT_BackConnectionHostnames=%%k
)

HKEY_Local_Machine\System\CurrentControlSet\Services\LanmanServer\Parameters 
echo STRICT         - %SMT_DisableStrictNameChecking%
echo LOOP           - %SMT_DisableLoopbackChecking%
echo NAMES          - %SMT_OptionalNames%
echo BACKCONNECTION - %SMT_BackConnectionHostnames%
echo.

echo ^+------------------------------------------------------------^+
echo ^| PROCESS: Processes, PID, context                           ^|
echo ^+------------------------------------------------------------^+
tasklist /fo table
echo.

echo ^+------------------------------------------------------------^+
echo ^| PORTS: IP Address, Port, Protocol, PID                     ^|
echo ^+------------------------------------------------------------^+
netstat -aon
echo.

echo ^+------------------------------------------------------------^+
echo ^| NETWORK: Routing Rules                                     ^|
echo ^+------------------------------------------------------------^+
route print
echo.

echo ^+------------------------------------------------------------^+
echo ^| PROGRAMS: Installed Applications                           ^|
echo ^+------------------------------------------------------------^+
reg query HKLM\software\Microsoft\Windows\currentVersion\Uninstall /s

echo ^+------------------------------------------------------------^+
echo ^| SERVICES: Service names, state, type, startup mode         ^|
echo ^+------------------------------------------------------------^+
wmic service get Name, State, ServiceType, StartMode, StartName | find /v ""

echo ^+------------------------------------------------------------^+
echo ^| IIS: Website Friendly Names and Bindings     ^|
echo ^+------------------------------------------------------------^+

set APPCMD_PATH=%windir%\system32\inetsrv\appcmd.exe

if exist "%APPCMD_PATH%" (
    echo appcmd.exe found, gathering IIS website information...
    echo.

    "%APPCMD_PATH%" list site 
    echo.
) else (
    echo ERROR: appcmd.exe not found. IIS may not be installed on this machine.
    echo Skipping IIS Website Capture.
)
echo.
echo ^+------------------------------------------------------------^+
echo ^| TIME: Service configuration                                ^|
echo ^+------------------------------------------------------------^+
w32tm /query /configuration
echo.

echo ^+------------------------------------------------------------^+
echo ^| DISK: Local disk drive letter and data space information   ^|
echo ^+------------------------------------------------------------^+
wmic LogicalDisk Where DriveType="3" Get DeviceID, Size, FreeSpace 2> nul | find /v ""


echo ---------------------------------------------------------------------------------
echo Listing disk Model, DeviceID, Drive Letters, Size (GB), and Free Space (GB)...
echo ---------------------------------------------------------------------------------
 
powershell -NoProfile -Command ^
"$disks = Get-WmiObject Win32_DiskDrive; ^
foreach ($disk in $disks) { ^
    $partitions = Get-WmiObject -Query ('ASSOCIATORS OF {Win32_DiskDrive.DeviceID=''' + $disk.DeviceID + '''} WHERE AssocClass=Win32_DiskDriveToDiskPartition'); ^
    $letters = ''; $freeGB = 0; ^
    foreach ($part in $partitions) { ^
        $logical = Get-WmiObject -Query ('ASSOCIATORS OF {Win32_DiskPartition.DeviceID=''' + $part.DeviceID + '''} WHERE AssocClass=Win32_LogicalDiskToPartition'); ^
        foreach ($l in $logical) { ^
            $letters += $l.DeviceID + ' '; ^
            $freeGB += [math]::Round($l.FreeSpace / 1GB, 2); ^
        } ^
    }; ^
    Write-Output ($disk.Model + ' - ' + $disk.DeviceID + ' - ' + $letters.Trim() + ' - ' + [math]::Round($disk.Size / 1GB, 2) + ' GB - ' + $freeGB + ' GB') ^
}"

echo.    
echo. 

echo ^+------------------------------------------------------------^+
echo ^| DISK: Network disk drive letter and data space information ^|
echo ^+------------------------------------------------------------^+
wmic LogicalDisk Where DriveType="4" Get DeviceID, Size, FreeSpace 2> nul | find /v ""

echo ^+------------------------------------------------------------^+
echo ^| DISK: CD-ROM / DVD drive letter information ^|
echo ^+------------------------------------------------------------^+
wmic LogicalDisk Where DriveType="5" Get DeviceID, Size, FreeSpace 2> nul | find /v ""

echo ^+------------------------------------------------------------^+
echo ^| SHARES: Share configuration                               ^|
echo ^+------------------------------------------------------------^+
wmic share get Caption, Name, Path | find /v ""

echo ^+------------------------------------------------------------^+
echo ^| LOCAL ADMINISTRATORS: Membership of local administrators   ^|
echo ^+------------------------------------------------------------^+
net localgroup administrators

echo ^+------------------------------------------------------------^+
echo ^| HOST FILE: Host file entries                               ^|
echo ^+------------------------------------------------------------^+
type %WINDIR%\system32\drivers\etc\hosts | find /v "#" | find "."
echo.

echo ^+------------------------------------------------------------^+
echo ^| LICENSE: Windows OS licensing status                       ^|
echo ^+------------------------------------------------------------^+
cscript //nologo C:\Windows\System32\slmgr.vbs /dli | find ":"
echo.
cscript //nologo C:\Windows\System32\slmgr.vbs /dlv | find ":"
echo.

echo ^+------------------------------------------------------------^+
echo ^| Installed .Net versions                                    ^|
echo ^+------------------------------------------------------------^+
dir %WINDIR%\Microsoft.Net\Framework\v* /O:-N /B

set SMT_OSComputername=
set SMT_OSName=
set SMT_OSType=
set SMT_TimeZone=
set SMT_NumberOfCores=
set SMT_TotalPhysicalMemory=
set SMT_DisableStrictNameChecking=
set SMT_DisableLoopbackChecking=
set SMT_OptionalNames=
set SMT_BackConnectionHostnames=


